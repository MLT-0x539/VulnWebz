# VulnWebApp
Intentionally vulnerable web application

# WARNING
This web application is intentionally vulnerable. I strongly advise you to make sure that you are the only one who can access this web application.

# Vulnerabilities
XSS, XSSi, Blind XSS, IDOR, CORS Misconfiguration, CSRF, SQL Injection, Blind SQL Injection, Open Redirect, and Reflected File Download
